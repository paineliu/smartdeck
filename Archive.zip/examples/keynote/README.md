Example keynote template placeholder.
